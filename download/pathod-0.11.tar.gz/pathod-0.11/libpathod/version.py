IVERSION = (0, 11)
VERSION = ".".join(str(i) for i in IVERSION)
MINORVERSION = ".".join(str(i) for i in IVERSION[:2])
NAME = "pathod"
NAMEVERSION = NAME + " " + VERSION
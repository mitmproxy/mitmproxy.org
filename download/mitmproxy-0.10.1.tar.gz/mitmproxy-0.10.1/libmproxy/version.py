IVERSION = (0, 10, 1)
VERSION = ".".join(str(i) for i in IVERSION)
MINORVERSION = ".".join(str(i) for i in IVERSION[:1])
NAME = "mitmproxy"
NAMEVERSION = NAME + " " + VERSION

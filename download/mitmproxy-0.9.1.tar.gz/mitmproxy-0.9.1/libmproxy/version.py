IVERSION = (0, 9, 1)
VERSION = ".".join(str(i) for i in IVERSION)
NAME = "mitmproxy"
NAMEVERSION = NAME + " " + VERSION

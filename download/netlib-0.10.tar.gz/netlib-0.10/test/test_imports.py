# These are actually tests!
import netlib.http_status
import netlib.version

**mitmproxy** is an interactive, SSL-capable man-in-the-middle proxy for HTTP
with a console interface.

**mitmdump** is the command-line version of mitmproxy. Think tcpdump for HTTP.

**libmproxy** is the library that mitmproxy and mitmdump are built on.

Complete documentation and a set of practical tutorials is included in the
distribution package, and is also available at mitmproxy.org_.

.. _mitmproxy.org: http://mitmproxy.org

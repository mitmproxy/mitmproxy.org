def request(ctx, r):
    raise ValueError

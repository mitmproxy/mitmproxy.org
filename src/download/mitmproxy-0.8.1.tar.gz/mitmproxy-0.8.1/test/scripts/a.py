
var = 0
def here(ctx):
    global var
    var += 1
    return var

def errargs():
    pass

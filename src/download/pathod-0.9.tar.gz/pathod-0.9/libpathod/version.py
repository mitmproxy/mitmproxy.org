IVERSION = (0, 9)
VERSION = ".".join(str(i) for i in IVERSION)
NAME = "pathod"
NAMEVERSION = NAME + " " + VERSION
